# LINEWORK Studio — Barbershop V7

## Open the template

Extract the ZIP and open `index.html` in your browser. Edit the same file in a text editor and replace the demo business details before publishing.

A precision cut-and-braid atelier with a technical editorial identity, built for the Senthan & Co Barbershop collection.

## Signature direction

- Geometric linework and drafting-grid visual language
- Ink-black, paper and signal-yellow palette
- Seven-image verified pattern library
- Interactive three-step Service Composer
- Fictional Nakasero, Kampala business details
- Thirteen unique photographs from the supplied `barbershop.zip`; no photo repeats inside V7 or overlaps the currently pushed templates

## Production standard

- One self-contained HTML file
- editable photo slots
- System-aware light and dark themes with saved override
- Eight languages: English, Spanish, French, German, Portuguese, Arabic, Chinese and Swahili
- Full Arabic RTL layout
- Responsive navigation, imagery and forms
- IntersectionObserver scroll reveals and reduced-motion support
- Defensive `localStorage` access
- Back-to-Top Button
- Demo-only booking form

## Credit

Built by **Senthan & Co**.

## Add your own photos

1. Create a `photos/` folder beside `index.html` and put your own images there.
2. Open `index.html` in a text editor. Find `PHOTO_SLOTS` near the end of the `<head>`. Set a slot’s `file` value to a relative path such as `photos/hero.webp`. The width and height show the recommended image ratio.
3. Save and refresh the page. Keep the important part of each image near the center and check the crop at both desktop and phone widths. Keep the photos folder beside the HTML when you publish.

## License

Your order records the license you purchased. See the [Senthan Commerce terms and template licenses](https://shop.senthan.work/terms) for the scope of your license and the rules for sharing the source files.
