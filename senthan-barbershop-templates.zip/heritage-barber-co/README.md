# Heritage Barber Co. — Vintage Barbershop Template

## Open the template

Extract the ZIP and open `index.html` in your browser. Edit the same file in a text editor and replace the demo business details before publishing.

A single-file, dependency-free landing page for a classic, old-world barbershop. Part of the **Senthan & Co** barbershop template set — this is Version 1 of the 7-theme production collection, built around a "family trade since 1962" identity: leather chairs, straight razors, ledger typography, and a hand-coded CSS barber pole.

## Live sections

- Sticky nav with language switcher + dark/light toggle
- Hero with a pure-CSS animated barber pole (no image/gif)
- "The Craft" — services styled as ticket stubs, mono-spaced pricing
- "Heritage" — a real chronological timeline (1962 → today)
- Gallery of tool photography
- "Meet the Barbers" — wax-seal monogram avatars (no stock headshots needed)
- Testimonials
- Booking section with a front-end contact form + WhatsApp-ready contact block

## Tech

- Pure HTML/CSS/JS, single file, **zero build step**
- Editable slots for your own photographs
- CSS custom properties power the dark/light theme (`data-theme` attribute)
- 8-language i18n (English, Spanish, French, German, Portuguese, Arabic, Chinese, Swahili) via `data-i18n` attributes + a JS dictionary — Arabic ships with full RTL mirroring
- `IntersectionObserver` scroll reveals, respects `prefers-reduced-motion`
- First visit follows `navigator.language`; the visitor can switch languages and the choice is remembered.
- Defensive `localStorage` wrapper (falls back to in-memory state if storage is blocked, e.g. in sandboxed previews)

## Customize

| What | Where |
|---|---|
| Brand name, tagline, est. year | Search `Heritage Barber Co.` and `1962` in `index.html` |
| Colors | `:root[data-theme="dark"]` / `:root[data-theme="light"]` custom properties near the top of `<style>` |
| Fonts | Font-family declarations in the main `<style>` block; the template uses dependency-free system fallbacks |
| Copy & translations | `translations` object near the bottom `<script>` — one object per language code |
| Photos | Edit the file paths in `PHOTO_SLOTS` |
| Contact details | `.book-contacts` block (fictional Uganda address, phone, and email) |
| Booking form | Wire `#bookForm`'s submit handler to Formspree, EmailJS, or your own backend |

## Adding a language

1. Duplicate any language block inside the `translations` object.
2. Translate each value (keep the keys identical).
3. Add an `<option>` to `#langSelect` in the nav.
4. If the language reads right-to-left, add its code to the `lang === 'ar'` check in `applyLanguage()`.

## Browser support

Modern evergreen browsers (Chrome, Firefox, Safari, Edge). Uses `IntersectionObserver`, CSS custom properties, and `backdrop-filter` — all widely supported; the page degrades gracefully (reveals just show immediately) if `IntersectionObserver` is unavailable.

## Credits

Built by **Senthan & Co**.

All business contact and location details shown in this template are fictional demo data.

## Add your own photos

1. Create a `photos/` folder beside `index.html` and put your own images there.
2. Open `index.html` in a text editor. Find `PHOTO_SLOTS` near the end of the `<head>`. Set a slot’s `file` value to a relative path such as `photos/hero.webp`. The width and height show the recommended image ratio.
3. Save and refresh the page. Keep the important part of each image near the center and check the crop at both desktop and phone widths. Keep the photos folder beside the HTML when you publish.

## License

Your order records the license you purchased. See the [Senthan Commerce terms and template licenses](https://shop.senthan.work/terms) for the scope of your license and the rules for sharing the source files.
