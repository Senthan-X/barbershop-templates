# Hue & Curl Studio — Natural Hair & Color Studio Template

## Open the template

Extract the ZIP and open `index.html` in your browser. Edit the same file in a text editor and replace the demo business details before publishing.

A single-file, dependency-free landing page for a natural hair and color studio. Archived legacy theme in the **Senthan & Co** barbershop/salon collection — warm, vibrant, and visually expressive.

## Live sections

- Sticky nav, language switcher, dark/light toggle
- Hero with a soft morphing organic "color blob" behind the photo (pure CSS, no image/svg)
- Services built around curl type and color, not a generic cut menu
- "The Color Menu" — a visual swatch-dot row (Cherry Red, Rose Gold, Honey Blonde, Natural Black, Copper, Lavender)
- Gallery of natural hair and color photography
- Stylist team cards with gradient monogram avatars
- Client testimonials
- Booking section with front-end form + WhatsApp-ready contact block

## Tech

Single HTML file, zero build step, editable photo slots, CSS custom property theming, 8-language i18n (`data-i18n` + JS dictionary, full Arabic RTL), first-visit browser-language detection, `IntersectionObserver` scroll reveals, defensive `localStorage` wrapper.

## Customize

| What | Where |
|---|---|
| Brand name | Search "Hue & Curl Studio" throughout |
| Colors | `:root[data-theme="light"]` / `"dark"` — `--coral`, `--berry`, `--gold` are the signature accents |
| Fonts | Font-family declarations in the main `<style>` block; the templates use dependency-free system fallbacks |
| Copy & translations | `translations` object near the bottom `<script>` |
| Photos | Edit the file paths in `PHOTO_SLOTS` |
| Color swatches | `.swatch-dot` inline styles in the Color Menu section |
| Booking form | Wire `#bookForm` to Formspree, EmailJS, or your own backend |

## Credits

Built by **Senthan & Co**.

All contact and location details in the template are fictional demo data.

## Add your own photos

1. Create a `photos/` folder beside `index.html` and put your own images there.
2. Open `index.html` in a text editor. Find `PHOTO_SLOTS` near the end of the `<head>`. Set a slot’s `file` value to a relative path such as `photos/hero.webp`. The width and height show the recommended image ratio.
3. Save and refresh the page. Keep the important part of each image near the center and check the crop at both desktop and phone widths. Keep the photos folder beside the HTML when you publish.

## License

Your order records the license you purchased. See the [Senthan Commerce terms and template licenses](https://shop.senthan.work/terms) for the scope of your license and the rules for sharing the source files.
