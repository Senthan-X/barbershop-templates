# Modern Gentleman — Contemporary Barbering Template

## Open the template

Extract the ZIP and open `index.html` in your browser. Edit the same file in a text editor and replace the demo business details before publishing.

A self-contained premium barbershop landing page and Version 2 of the **Senthan & Co** barbershop collection. Modern Gentleman pairs restrained editorial typography, warm brass detailing, and carefully selected grooming imagery with a conversion-focused booking journey.

## Experience

- Full-background responsive hero with independently tuned desktop and mobile crops
- Four service rituals with purposeful animated icon badges
- 36-style Journal with editable photo slots
- Six category filters, 12-style featured view, and progressive catalog expansion
- “Choose this style” actions that carry a selection into the booking form
- Trust metrics, barber profiles, testimonials, and booking/contact sections
- System-aware light/dark theme with a remembered visitor override
- Seven embedded languages: English, Spanish, French, German, Portuguese, Arabic with RTL, and Chinese
- IntersectionObserver reveals, reduced-motion support, and animated Back-to-Top Button
- Defensive localStorage and browser-language detection

## Architecture

One zero-dependency HTML file with editable photo slots, CSS custom properties, semantic markup, inline SVG icons, and `window.I18N` translations. No external fonts, scripts, or CDN requests are required.

## Customization

| Item | Location |
|---|---|
| Brand and content | Semantic HTML plus the `I18N` object |
| Theme palette | `:root[data-theme="dark"]` and `:root[data-theme="light"]` |
| Photos | Edit the file paths in `PHOTO_SLOTS` |
| Booking handler | `#bookForm` submit listener |
| Contact number | Booking contact link |

## Credits

Crafted by **Senthan & Co**. Contact details shown in this template are fictional demo placeholders.

## Add your own photos

1. Create a `photos/` folder beside `index.html` and put your own images there.
2. Open `index.html` in a text editor. Find `PHOTO_SLOTS` near the end of the `<head>`. Set a slot’s `file` value to a relative path such as `photos/hero.webp`. The width and height show the recommended image ratio.
3. Save and refresh the page. Keep the important part of each image near the center and check the crop at both desktop and phone widths. Keep the photos folder beside the HTML when you publish.

## License

Your order records the license you purchased. See the [Senthan Commerce terms and template licenses](https://shop.senthan.work/terms) for the scope of your license and the rules for sharing the source files.
