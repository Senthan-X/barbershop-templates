# Urban Cut Studio — Barbershop V3

## Open the template

Extract the ZIP and open `index.html` in your browser. Edit the same file in a text editor and replace the demo business details before publishing.

A single-file, dependency-free barbershop template with a street-editorial identity, 36 visually verified hairstyle entries, six catalog filters, a Cut Matcher, and style-linked booking.

## Included

- 36 editable hairstyle photo slots
- Six catalog filters with 12 featured styles and View All
- Cut Matcher signature interaction
- Style-to-booking linkage
- System-responsive light and dark themes with remembered override
- Seven embedded languages: EN, ES, FR, DE, PT, AR, ZH
- Full Arabic RTL layout
- Responsive navigation and full-background hero
- IntersectionObserver reveals and reduced-motion support
- Fictional demonstration contact details
- Back-to-Top Button
- Zero external runtime dependencies

Built by **Senthan & Co**.

## Add your own photos

1. Create a `photos/` folder beside `index.html` and put your own images there.
2. Open `index.html` in a text editor. Find `PHOTO_SLOTS` near the end of the `<head>`. Set a slot’s `file` value to a relative path such as `photos/hero.webp`. The width and height show the recommended image ratio.
3. Save and refresh the page. Keep the important part of each image near the center and check the crop at both desktop and phone widths. Keep the photos folder beside the HTML when you publish.

## License

Your order records the license you purchased. See the [Senthan Commerce terms and template licenses](https://shop.senthan.work/terms) for the scope of your license and the rules for sharing the source files.
