# Barber Collective — V6

## Open the template

Extract the ZIP and open `index.html` in your browser. Edit the same file in a text editor and replace the demo business details before publishing.

An inclusive collaborative barbershop concept by Senthan & Co. Delivered as one self-contained HTML file with editable photo slots, eight languages, full Arabic RTL, system-aware light/dark themes, responsive layout, reduced-motion support, scroll reveals, Back-to-Top Button, and the interactive “Find Your Chair” lookbook filter.

All contact details are fictional East African demo data.

## Add your own photos

1. Create a `photos/` folder beside `index.html` and put your own images there.
2. Open `index.html` in a text editor. Find `PHOTO_SLOTS` near the end of the `<head>`. Set a slot’s `file` value to a relative path such as `photos/hero.webp`. The width and height show the recommended image ratio.
3. Save and refresh the page. Keep the important part of each image near the center and check the crop at both desktop and phone widths. Keep the photos folder beside the HTML when you publish.

## License

Your order records the license you purchased. See the [Senthan Commerce terms and template licenses](https://shop.senthan.work/terms) for the scope of your license and the rules for sharing the source files.
