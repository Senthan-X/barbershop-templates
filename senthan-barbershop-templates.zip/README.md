# Senthan & Co — Barbershop & Salon Templates

Nine distinct, self-contained HTML templates for barbershops, grooming lounges, braid studios, and hair salons: the complete V1–V7 production series plus two live legacy themes.

## Templates

| Template | Folder | Direction |
|---|---|---|
| Heritage Barber Co. | [`heritage-barber-co`](./heritage-barber-co/index.html) | Classic vintage barbershop |
| Fade Lab | [`fade-lab`](./fade-lab/index.html) | Modern urban fades and hair art |
| Urban Cut Studio | [`noir-blade`](./noir-blade/index.html) | Street-forward cuts, braids and texture |
| AURELIS Grooming Club | [`luxury-grooming-club`](./luxury-grooming-club/index.html) | Luxury appointment-only grooming club |
| Hue & Curl Studio | [`hue-curl-studio`](./hue-curl-studio/index.html) | Natural hair and color studio |
| The Braid Bar | [`braid-bar`](./braid-bar/index.html) | Community braiding salon |
| Corner Chair | [`neighborhood-barber`](./neighborhood-barber/index.html) | Friendly neighborhood barbershop |
| Barber Collective | [`barber-collective`](./barber-collective/index.html) | Inclusive collaborative studio with interactive style filtering |
| LINEWORK Studio | [`linework-studio`](./linework-studio/index.html) | Precision cut-and-braid atelier |

Extract the ZIP and open the [collection index](./index.html) in your browser. Keep the template folders beside the collection index. Open a template's own `index.html` to customize it.

## Shared architecture

- Single-file HTML per template with no runtime dependencies
- Editable photo slots in each template
- Responsive light and dark themes that follow the visitor’s system setting by default
- Manual theme override saved defensively in `localStorage`
- Eight embedded languages: English, Spanish, French, German, Portuguese, Arabic, Chinese and Swahili
- Full right-to-left layout for Arabic
- IntersectionObserver scroll reveals with reduced-motion support
- Theme-specific, keyboard-accessible closer-look previews for gallery and lookbook imagery
- Responsive navigation, booking form demo, skip link, and Back-to-Top Button

The booking forms are front-end demonstrations and do not require an account. Connect them to the buyer’s preferred form handler before production use. All displayed contact details are fictional East African demo data.

## Deployment

Upload the customized `index.html` from the template you chose to your static web host.

## Credit

Built by **Senthan & Co**.

## Add your own photos

Open the chosen template folder and follow its `README.md`. Each template has its own photo settings. Add photos to each folder you plan to publish.

## License

Your order records the license you purchased. See the [Senthan Commerce terms and template licenses](https://shop.senthan.work/terms) for the scope of your license and the rules for sharing the source files.
