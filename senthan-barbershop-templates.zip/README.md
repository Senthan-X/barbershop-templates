# Senthan & Co — Barbershop & Salon Templates

Nine distinct, self-contained HTML templates for barbershops, grooming lounges, braid studios, and hair salons: the complete V1–V7 production series plus two live legacy themes.

## Templates

| Template | Folder | Direction |
|---|---|---|
| Heritage Barber Co. | [`heritage-barber-co`](./heritage-barber-co/) | Classic vintage barbershop |
| Fade Lab | [`fade-lab`](./fade-lab/) | Modern urban fades and hair art |
| Urban Cut Studio | [`noir-blade`](./noir-blade/) | Street-forward cuts, braids and texture |
| AURELIS Grooming Club | [`luxury-grooming-club`](./luxury-grooming-club/) | Luxury appointment-only grooming club |
| Hue & Curl Studio | [`hue-curl-studio`](./hue-curl-studio/) | Natural hair and color studio |
| The Braid Bar | [`braid-bar`](./braid-bar/) | Community braiding salon |
| Corner Chair | [`neighborhood-barber`](./neighborhood-barber/) | Friendly neighborhood barbershop |
| Barber Collective | [`barber-collective`](./barber-collective/) | Inclusive collaborative studio with interactive style filtering |
| LINEWORK Studio | [`linework-studio`](./linework-studio/) | Precision cut-and-braid atelier |

Open the [collection index](./index.html) to browse live previews rendered from the actual templates.

## Shared architecture

- Single-file HTML per template with no runtime dependencies
- Base64-embedded WebP photography
- Responsive light and dark themes that follow the visitor’s system setting by default
- Manual theme override saved defensively in `localStorage`
- Eight embedded languages: English, Spanish, French, German, Portuguese, Arabic, Chinese and Swahili
- Full right-to-left layout for Arabic
- IntersectionObserver scroll reveals with reduced-motion support
- Theme-specific, keyboard-accessible closer-look previews for gallery and lookbook imagery
- Responsive navigation, booking form demo, skip link, and Back-to-Top Button

The booking forms are front-end demonstrations and do not require an account. Connect them to the buyer’s preferred form handler before production use. All displayed contact details are fictional East African demo data.

## Deployment

The repository includes a GitHub Pages workflow. Each template can also be deployed independently by copying its folder, or by uploading its `index.html` as a standalone page.

## Credit

Built by **Senthan & Co**.
