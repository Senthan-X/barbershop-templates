# Senthan Barbershop Templates

Six distinct, self-contained HTML landing pages for barbershops, braid studios, and hair salons — built by **Senthan & Co**. Each template has its own visual identity, but all six share the same production architecture.

**[→ View the collection index](./index.html)**

## The six templates

| Template | Folder | Identity |
|---|---|---|
| **Heritage Barber Co.** | [`/heritage-barber-co`](./heritage-barber-co) | Classic vintage barbershop — "since 1962," animated CSS barber pole, ticket-stub service menu |
| **Fade Lab** | [`/fade-lab`](./fade-lab) | Modern urban fade & hair-art studio — bold lime/coral, grade-badge service cards |
| **Noir Blade** | [`/noir-blade`](./noir-blade) | Luxury black & gold grooming lounge — appointment-only, 4-step "Ritual" section |
| **Crown Braids** | [`/crown-braids`](./crown-braids) | Men's braid specialist studio — regal Cinzel type, braid-weave CSS divider |
| **Hue & Curl Studio** | [`/hue-curl-studio`](./hue-curl-studio) | Natural hair & color studio — warm palette, swatch-dot color menu |
| **The Braid Bar** | [`/braid-bar`](./braid-bar) | Community braiding salon — walk-in energy, chalkboard-style menu board |

Each subfolder is a complete, independent template with its own `index.html` and `README.md` — copy any single folder's `index.html` and it works standalone; nothing links back to this repo structure at runtime.

## Shared architecture

- **Single HTML file per template** — zero build step, zero dependencies
- **Base64-embedded WebP photography** — no `/assets` folder to lose on upload
- **Dark/light mode** via `data-theme` + CSS custom properties (each template picks its own sensible default)
- **7-language i18n** — English, Spanish, French, German, Portuguese, Swahili, and Arabic (full RTL) — via `data-i18n` attributes + a JS dictionary
- **Scroll-reveal animation** via `IntersectionObserver`, respecting `prefers-reduced-motion`
- **Defensive `localStorage` wrapper** — falls back to in-memory state if storage is blocked (private browsing, sandboxed previews)
- **Front-end booking form** on every template — ready to wire up to Formspree, EmailJS, or a custom backend

## Using this repo

**As a GitHub Pages site:** enable Pages on this repo (root or `/docs`), and `index.html` becomes a browsable directory linking to all six live templates.

**For Codester / marketplace listing:** each subfolder's `index.html` + `README.md` is the complete buyer package for that individual template — list them separately.

## Credits

Built by **Senthan & Co**.
📞 +256 754 069 314 · ✉️ jonathanrivers0414@gmail.com
