# AURELIS — Luxury Grooming Club

Barbershop collection Version 4 by Senthan & Co.

## Highlights

- Zero-dependency, self-contained HTML
- 18 editable hairstyle photo slots
- Verified image-to-style naming
- Full-color responsive imagery
- System-aware light and dark themes with remembered override
- Seven languages: EN, ES, FR, DE, PT, AR (RTL), and ZH
- Interactive Ritual Concierge
- Filterable style catalog with booking linkage
- Responsive navigation, scroll reveals, reduced-motion support, and Back-to-Top Button
- Fictional East African demo address and telephone number

Open `index.html` directly in a modern browser.

## Add your own photos

1. Create a `photos/` folder beside `index.html` and put your own images there.
2. Open `index.html` in a text editor. Find `PHOTO_SLOTS` near the end of the `<head>`. Set a slot’s `file` value to a relative path such as `photos/hero.webp`. The width and height show the recommended image ratio.
3. Save and refresh the page. Keep the important part of each image near the center and check the crop at both desktop and phone widths. Keep the photos folder beside the HTML when you publish.

## License

Your order records the license you purchased. See the [Senthan Commerce terms and template licenses](https://shop.senthan.work/terms) for the scope of your license and the rules for sharing the source files.
